// Tweaks app for Offline Home
function mountTweaks() {
  if (!window.TweaksPanel) { setTimeout(mountTweaks, 50); return; }
  const { TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakToggle, TweakText, TweakSelect } = window;
  const root = ReactDOM.createRoot(document.getElementById('tweaksRoot'));

  function App() {
    const [tweaks, setTweak] = useTweaks(window.TWEAK_DEFAULTS);

    React.useEffect(() => { window.applyMood(tweaks.heroMood); }, [tweaks.heroMood]);
    React.useEffect(() => {
      document.documentElement.style.setProperty('--display',
        '"' + tweaks.displayFont + '", "Archivo Black", system-ui, sans-serif');
    }, [tweaks.displayFont]);
    React.useEffect(() => {
      const el = document.getElementById('heroHeadline');
      if (el) el.innerHTML = (tweaks.heroHeadline || '').replace('. ', '.<br>');
    }, [tweaks.heroHeadline]);
    React.useEffect(() => {
      const c = document.getElementById('cursorCoord');
      if (c) c.style.display = tweaks.showCursorCoord ? '' : 'none';
    }, [tweaks.showCursorCoord]);
    React.useEffect(() => {
      const c = document.querySelector('.hero-character');
      if (c) c.style.display = tweaks.showCharacter ? '' : 'none';
    }, [tweaks.showCharacter]);

    return (
      <TweaksPanel title="Tweaks">
        <TweakSection label="Hero mood">
          <TweakRadio
            label="Active blend"
            value={tweaks.heroMood}
            onChange={v => setTweak('heroMood', v)}
            options={[
              { value: 'amber', label: 'Amber' },
              { value: 'ember', label: 'Ember' },
              { value: 'pine',  label: 'Pine'  }
            ]}
          />
          <TweakText
            label="Headline"
            value={tweaks.heroHeadline}
            onChange={v => setTweak('heroHeadline', v)}
          />
        </TweakSection>

        <TweakSection label="Type">
          <TweakSelect
            label="Display font"
            value={tweaks.displayFont}
            onChange={v => setTweak('displayFont', v)}
            options={[
              { value: 'Anton', label: 'Anton' },
              { value: 'Archivo Black', label: 'Archivo Black' },
              { value: 'Bebas Neue', label: 'Bebas Neue' },
              { value: 'Gulfs Display', label: 'Gulfs Display' }
            ]}
          />
        </TweakSection>

        <TweakSection label="Delight">
          <TweakToggle
            label="Cursor coordinate"
            value={tweaks.showCursorCoord}
            onChange={v => setTweak('showCursorCoord', v)}
          />
          <TweakToggle
            label="Character mark in hero"
            value={tweaks.showCharacter}
            onChange={v => setTweak('showCharacter', v)}
          />
        </TweakSection>
      </TweaksPanel>
    );
  }

  root.render(<App />);
}
mountTweaks();
