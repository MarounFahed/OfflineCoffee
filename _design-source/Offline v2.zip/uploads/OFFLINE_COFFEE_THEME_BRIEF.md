# OFFLINE — Shopify Theme Build Brief

> Build a complete, working Shopify theme (Online Store 2.0, Liquid + JSON templates) for **Offline**, a steeped coffee brand for people who want their morning without notifications. Ship it as a real, deployable theme — not a mockup. Lean into the brand. Make it feel like a place, not a website.

---

## 0. Read this first

You are designing and building a **Shopify Online Store 2.0 theme** end-to-end. The brand voice is "outdoor / off-grid / slow morning." The product is **steeped coffee** — single-serve coffee bags that brew like tea, anywhere, in 4 minutes, no machine required. Tents. Trains. Hotel rooms. Porches. Cabins with no WiFi. The whole product is permission to be unreachable for ten minutes.

Your job is to make every pixel feel like that promise.

This is **not** a generic Dawn re-skin. Treat Dawn as a starting skeleton if useful, but the visual language, sectioning, and copy should feel custom-built for Offline. Be opinionated. Break grids on purpose. Let big type breathe. Use the cream as a canvas, the black sparingly and decisively, and the roast colors like landscape — not like swatches.

---

## 1. Brand foundation

### 1.1 Mission
Offline makes coffee for the moments you'd rather not be online. Real specialty-grade beans, ground fresh, sealed in compostable filter sachets. Add hot water. Wait four minutes. Drink something better than what the hotel lobby is offering.

### 1.2 Voice
- **Confident, not preachy.** We sell coffee, not enlightenment. Never lecture about screen time.
- **Plainspoken.** No jargon, no faux-rustic affectations, no "artisanal journey" copy.
- **Dry, occasionally funny.** A small smirk, never a wink.
- **Outdoor-shaped, but not gatekeeping.** A balcony is offline too.
- **Specific over poetic.** "Brews in 4 minutes at 200°F" beats "an unhurried ritual."

### 1.3 Voice cheat sheet
| Don't say | Do say |
|---|---|
| "Embark on a coffee journey" | "It's coffee. It's good. It travels." |
| "Artisanal small-batch craft" | "Roasted in small batches. Ground the same week." |
| "Disconnect from the digital world" | "Out of range. On purpose." |
| "Premium experience" | "Tastes like the cafe you'd actually go back to." |

### 1.4 Audience
Backpackers and weekenders, hotel coffee skeptics, parents who can't run a French press at 6am, train commuters, van-lifers, people who travel with a kettle, anyone who's ever poured a packet of brown dust into a paper cup at a Best Western and given up on the day.

### 1.5 Tagline options (use the first; rotate the others as section headers, footers, packaging callouts)
1. **Out of range. On purpose.**
2. No machine. No noise. Just coffee.
3. Made for the places without WiFi.
4. Four minutes to anywhere.
5. The internet can wait.

---

## 2. Color system

The palette is small and load-bearing. Don't add to it. Use the roast colors as **moods**, not as accents — assign one roast color to each blend's entire on-site world (PDP hero, collection card, product packaging mockup background, related editorial).

### 2.1 Core
| Token | Hex | Role |
|---|---|---|
| `--paper` | `#F5F1E8` | Default page background. Warm oat. Used 80% of the surface area. |
| `--ink` | `#0F0F0F` | Primary type, primary CTA, the wordmark. The only "black." |

### 2.2 Roast moods (map 1:1 to product blends)
| Token | Hex | Roast | Mood / landscape |
|---|---|---|---|
| `--amber` | `#D4923A` | Light roast | Morning sun on aspen, honey light, dawn |
| `--ember` | `#B85C38` | Medium roast | Terracotta, sunset desert, crema |
| `--pine` | `#3D5240` | Dark roast | Deep evergreen, moss after rain, dusk |

### 2.3 Derived tokens (compute, don't hand-pick)
- `--paper-2`: `#EFEADC` (slightly deeper paper for cards on paper background)
- `--rule`: `#0F0F0F` at 12% — for hairlines and dividers
- `--ink-soft`: `#0F0F0F` at 70% — secondary type only
- Roast washes: each roast color at 8% over `--paper` for full-bleed mood sections

### 2.4 Rules of use
- **Never** put a roast color on a roast color. The roast is a stage; cream and ink are the actors.
- **Never** put white (`#FFFFFF`) on the site. The off-white paper is the base. White breaks the world.
- **CTAs** are always `--ink` on `--paper`, or inverted. No colored buttons.
- **The roast color** appears as a full-bleed background for that blend's sections, on the bag mockup, and in one accent rule per product card. That's it.
- Verify all combinations clear **WCAG AA** (4.5:1 body, 3:1 large type). Spot-check `--ink-soft` on `--paper` and adjust opacity if it fails.

---

## 3. Typography

Use **two faces, three weights total**. No more.

### 3.1 Display: a chunky, slightly condensed sans with attitude
Match the energy of the wordmark — heavy, wide, slightly clipped feeling. Strong recommendations (any of these works):
- **Druk Wide / Druk Text Wide** (paid, ideal)
- **Migra** or **Migra Italic** (paid, characterful)
- **Bagoss Standard** (paid, modern)
- **Free fallback:** **Anton** + custom letter-spacing tweak, OR **Archivo Black** with `letter-spacing: -0.02em`

Use display only at **48px and above** on desktop, **32px and above** on mobile. Display below those sizes looks like packaging gone wrong.

### 3.2 Text: a humanist serif with warmth and a little personality
- **Fraunces** (free, Google Fonts) — set with `opsz` 144 for headings, 14 for body, soft serifs, slight wedge — perfect tonal match.
- Alternative: **PolySans** (sans, paid) if you want a sans body instead of serif.

### 3.3 Mono: for metadata only
- **JetBrains Mono** (free) — used for tasting notes, brew specs, product metadata, footer details. Treat it like field notes, not code.

### 3.4 Type scale (desktop / mobile)
| Role | Face | Size (D/M) | Weight | Tracking | Leading |
|---|---|---|---|---|---|
| Display XL (hero) | Display | 144 / 72 | 800 | -0.02em | 0.95 |
| Display L | Display | 96 / 56 | 800 | -0.02em | 0.95 |
| Display M | Display | 64 / 40 | 800 | -0.01em | 1.0 |
| H1 (page) | Display | 48 / 32 | 800 | -0.01em | 1.05 |
| H2 (section) | Fraunces | 32 / 24 | 600 | -0.01em | 1.15 |
| H3 (card) | Fraunces | 22 / 20 | 600 | 0 | 1.2 |
| Body L | Fraunces | 18 / 17 | 400 | 0 | 1.55 |
| Body | Fraunces | 16 / 16 | 400 | 0 | 1.55 |
| Caption / meta | Mono | 12 / 12 | 500 | 0.08em UPPER | 1.4 |

### 3.5 Type rules
- **Hyphens off, widows handled.** Manual `<br>` or `text-wrap: balance` on all H1/H2.
- Never center long-form body. Center is reserved for hero one-liners and tagline cards.
- All-caps is **mono only**, and only for: nav, eyebrow labels, footer section titles, tasting note tags. Never on display or body.
- Italic Fraunces is welcome — use it for editorial pull-quotes and product story copy, never for emphasis in body.

---

## 4. Logo & identity assets

You will receive two logo files in the brief:

- **`Offline_Coffee.png`** — the primary stacked wordmark ("OFFLINE" / "COFFEE" small caps subscript). Use on light surfaces.
- **`Offline_Coffee__1_.png`** — the cleaner / inverted variant. Use on dark surfaces or roast-color backgrounds.

### 4.1 Logo rules
- Minimum width: 120px on web, 80px on mobile header.
- Clear space: at least the height of the "O" on all sides.
- Never re-color the wordmark. It's `--ink` on light, `--paper` on dark. That's it.
- Never stretch, italicize, outline, drop-shadow, or animate transforms on the wordmark itself. It can fade in. It cannot dance.
- The favicon is just the "O" from "OFF" — render at 512px, export to `favicon.png` and `favicon.svg`.

### 4.2 Identity motifs (build these as reusable SVG snippets)
1. **Signal bars (inverted).** Cellular-style 1–4 bar icon, but used to indicate **disconnection level** of a product. Light roast = 1 bar. Medium = 2. Dark = 3. "All Offline" subscription = 0 bars with a line through. Use as a tiny meta tag on product cards.
2. **Topo line.** A single hand-drawn-feeling contour line used as a section divider. Looks like the topographic curves on a trail map. Build as inline SVG so it can stretch responsively.
3. **Coordinate stamp.** A small mono-type block in the corner of hero images: `N 38°51′ / W 119°57′ — STEEPED HERE`. The coordinates change per page (home, about, each blend, etc.). Treat them as found-object stamps, not data.
4. **Postage marks.** Hand-drawn rectangle frames around editorial images, like a passport stamp. Use sparingly — 1 per page max.

---

## 5. Imagery & art direction

### 5.1 What's missing (and how to handle it)
The merchant **does not yet have product photography**. The provided `Offline_Coffee.png` is a **placeholder** — wherever a real product shot or lifestyle image would go, use the placeholder image and label it semantically (e.g., `alt="Placeholder — Offline Light Roast bag, exterior shot"`). The merchant will swap these out later. Build all image components so swapping a placeholder for a real photo is a one-field metafield update — no code change.

### 5.2 Direction for future real photography (include this as a section in the theme docs / merchant onboarding)
- **Light, real, slightly underexposed.** Not studio-bright. Morning window light, overcast trail light, a tent at dawn.
- **Hands and steam.** Hands holding a mug. Steam over a cup on a granite outcrop. The kettle pouring. Never the bag floating on a seamless backdrop.
- **Negative space top or left.** So the chunky display type can land into the photo without fighting it.
- **No people's faces hero-on.** Backs of heads, shoulders, hands, boots. The viewer is the protagonist.
- **Consistent grade:** slight green-cyan in shadows, warm highlights. Like Kodak Portra pushed half a stop.

### 5.3 Where each image type lives
| Type | Source for now | Future replacement | Render size |
|---|---|---|---|
| Hero | placeholder + roast color wash | shot lifestyle video loop | 2400×1200 |
| PDP main | placeholder | studio + lifestyle pair | 2048×2048 |
| Collection card | placeholder + roast color wash | shot bag-only on roast color background | 1200×1500 |
| Editorial / blog | placeholder + topo line motif | shot lifestyle | 1600×1000 |
| About story | placeholder + coordinate stamp | shot location-specific | 1600×1000 |

### 5.4 No stock photos.
If a placeholder is needed beyond the provided one, use a **flat color block** in a roast color, not a stock image. A blank pine-green rectangle reads more on-brand than a moody Unsplash mug shot.

---

## 6. Layout principles

### 6.1 Grid
- Desktop: 12-column, 80px outer gutter, 24px column gap, max-width 1440px.
- Tablet: 8-column, 32px outer, 20px column gap.
- Mobile: 4-column, 20px outer, 16px column gap.
- **Break the grid intentionally** at least once per page — let display type bleed past the column edge into the gutter, or anchor a small caption at column 1 while the image spans 4–10.

### 6.2 Spacing scale (8pt base)
`4 / 8 / 12 / 16 / 24 / 32 / 48 / 64 / 96 / 128 / 192`
Use the same scale for margins, paddings, and gap. Never `padding: 17px`.

### 6.3 Vertical rhythm
- Section padding: `128px / 96px / 64px` (D / T / M) top and bottom by default.
- Hero sections: `192px / 128px / 96px`.
- Editorial sections (one big quote + image): `96px / 64px / 48px` and let the type carry the weight.

### 6.4 Hairlines, never boxes
- Use 1px `--rule` hairlines top/bottom of sections instead of background colors to separate. Cards rarely have full borders — they have a top hairline and bottom hairline only.
- Buttons are filled rectangles. Hairlines are for structure, not for buttons.

---

## 7. Component library

Build these as reusable Liquid snippets in `/snippets`. Every component below has a real spec.

### 7.1 Button
- **Primary:** `--ink` background, `--paper` text, no radius (sharp corners — chunky, like the wordmark), `padding: 16px 32px`, mono caps `12px / 0.08em`. On hover: invert (paper bg, ink text, 1px ink border).
- **Secondary:** transparent bg, 1px `--ink` border, ink text. On hover: ink bg, paper text.
- **Ghost / link:** ink text, 1px `--ink` underline with 4px offset. On hover: underline thickens to 2px.
- **No** rounded buttons. **No** drop shadows. **No** gradients.

### 7.2 Product card (collection grid)
Layout, top to bottom:
1. **Image:** 4:5 ratio, full-bleed in card. Background = the blend's roast color at 100%. Bag floats centered.
2. **Top hairline** (`--rule`).
3. **Mono row:** `LIGHT ROAST · 12 OZ · STEEPED` — this is the metadata row.
4. **Display name:** Fraunces 22px semibold, e.g., "Aspen Morning."
5. **Tasting notes row:** three small mono tags side by side: `HONEY` `STONE FRUIT` `CITRUS`.
6. **Price + signal bars:** price left, signal-bar icon right (1/2/3 bars depending on roast).
7. **Bottom hairline** (`--rule`).
8. On hover: the bag image **shifts up 8px**, the card top hairline grows from 1px to 2px. No other movement.

### 7.3 Hero block
- Full-viewport-height (min 720px desktop, 600px mobile).
- Background: roast color at 100% **OR** placeholder lifestyle image with a 30% multiply layer of the roast color.
- Foreground: Display XL headline, max 5 words, anchored bottom-left with 80px padding. Coordinate stamp top-right. CTA below headline.
- One scroll-cue: a tiny mono `↓ KEEP READING` bottom-center, 24px above the fold.

### 7.4 Editorial pull-quote block
- Full-bleed `--paper` background.
- Fraunces italic, 64px desktop / 40px mobile, max width 18 words, left-aligned at column 2 of 12.
- Attribution in mono caps below, 80px down.
- One topo-line SVG above the quote, full-width, 1px stroke at `--ink` 30%.

### 7.5 Tasting card (PDP)
- Three vertical columns separated by hairlines, no boxes:
  - **AROMA** — 3 mono tags + a Fraunces sentence
  - **PALATE** — 3 mono tags + a Fraunces sentence
  - **FINISH** — 3 mono tags + a Fraunces sentence
- Above the row: a small mono label `TRAIL NOTES — BLEND № 02`.
- Below the row: the brewing instructions (see 7.6).

### 7.6 Brew instructions strip
A horizontal strip of four steps, each with a number (00–03 in display), a Fraunces sentence, and a hairline below:
- **00 — Boil.** Fresh water, 200°F, just off the boil.
- **01 — Drop.** Place sachet in your mug. Tag out.
- **02 — Pour.** Fill to the brim. Steam counts.
- **03 — Wait.** Four minutes. Don't check your phone.

This is a signature module. It appears on the homepage, every PDP, and the about page. Build it once.

### 7.7 Subscription / "Resupply" card
Subscribe = "Resupply." The whole subscription model is framed as resupplying the trip.
- Headline: "Resupply." Fraunces 48px.
- Three plan options as horizontal tabs (mono caps): `WEEKLY` / `BIMONTHLY` / `MONTHLY`.
- Each shows: number of sachets, price/ship, "skip or cancel anytime — really" microcopy.
- CTA: primary button, "Stock the pack."

### 7.8 Footer
- Background: `--ink`. Type: `--paper`.
- Three columns: Shop / Story / Service.
- Above the columns: a giant `OFFLINE` wordmark, full-width, edge-to-edge, set in display 240px+ — this is a moment, not a logo. It crops at the baseline like a billboard.
- Below the columns: mono row with copyright, coordinate stamp, "Roasted in [TBD]. Steeped wherever."
- No social icons larger than the body text. The brand is offline; treat the social row like fine print.

---

## 8. Page specifications

Build all of these as **JSON templates** so the merchant can reorder sections.

### 8.1 Home (`templates/index.json`)
Section order:
1. **Hero** — full-bleed roast color (rotate or pick: pine on first paint), display XL headline `OUT OF RANGE. ON PURPOSE.`, sub Fraunces 18px in 2 lines, primary CTA "Shop the blends," secondary "Read the why," coordinate stamp top-right.
2. **Three blends row** — three product cards, side-by-side desktop, stacked mobile. Each card sits on its blend's roast color. Click → PDP.
3. **The brew strip** — section 7.6, full-bleed `--paper`. Heading: "Four minutes. That's it."
4. **Editorial pull-quote** — section 7.4. Quote rotates from a list in theme settings; default: *"You can drink coffee with two bars of signal, or no bars at all. The coffee doesn't care. Maybe you don't either."*
5. **Where it goes** — a 3-up grid of small editorial cards (placeholder image + caption): tents, trains, hotel rooms. Each card has a coordinate stamp. Headline: "Made for the places without good coffee."
6. **Resupply** — section 7.7.
7. **Journal preview** — three latest blog posts. Headline: "From the journal."
8. **Footer.**

### 8.2 Collection (`templates/collection.json`)
Section order:
1. **Collection header** — display L title, Fraunces 18px description (max 2 lines), one filter row in mono caps (`ROAST` / `INTENSITY` / `SUBSCRIPTION`). The filter row is **horizontal pills**, not a sidebar.
2. **Product grid** — 3-up desktop, 2-up tablet, 1-up mobile. Use product card 7.2.
3. **Editorial break every 6 products** — a full-bleed pull-quote or a single image card. This is what makes the collection feel like a magazine, not a feed.
4. **Footer.**

### 8.3 Product / PDP (`templates/product.json`)
Layout: split 50/50 desktop, stacked mobile.
- **Left:** image gallery. Main image bleeds to top of viewport. Background of gallery is the blend's roast color. Thumbnail strip below — small, mono captions ("BAG FRONT," "BAG BACK," "GROUNDS," "STEEPED").
- **Right:** content stack:
  1. Mono eyebrow: roast level + region (`MEDIUM ROAST · COLOMBIA HUILA`)
  2. Display M product name
  3. Fraunces 18px short description (3 lines max)
  4. Price + signal bars
  5. Variant selector (sachet count: 6 / 12 / 24)
  6. **One-time vs Resupply** toggle, mono caps
  7. Primary CTA: "Add to pack"
  8. Three accordion items below CTA, hairline-only borders: `BREW PERFECTLY`, `WHAT'S INSIDE`, `SHIPS WHEN`
- **Below the fold (full-bleed):**
  9. Tasting card (7.5)
  10. Brew strip (7.6)
  11. Origin block — placeholder image left, Fraunces story right, with one coordinate stamp
  12. Related products: "Other blends" — re-use 7.2
- **Footer.**

### 8.4 About / Story (`templates/page.about.json`)
This is the brand's manifesto. Treat it like a longform editorial.
1. **Manifesto hero** — `--paper` bg, no image, just one display XL line: `WE MADE COFFEE FOR THE PLACES WE'D RATHER BE.` Centered, max 8 words wide.
2. **Origin paragraph** — Fraunces 18px, 1 column, max-width 640px, centered. 3 paragraphs max.
3. **Image break** — placeholder, full-bleed, with a topo line above and coordinate stamp.
4. **The brew strip** (7.6).
5. **Pull-quote** (7.4).
6. **Sourcing** — 3 origin cards (placeholder + region name + altitude in mono).
7. **Compostable, not just recyclable** — small section about the sachets, full-bleed pine background, paper text, mono callout: `100% PLANT-BASED FILTER · OK FOR YOUR BACKYARD COMPOST`.
8. **Resupply CTA.**
9. **Footer.**

### 8.5 Cart (`templates/cart.json`)
- Full-page cart, not a drawer — for now. (Drawer is a fast-follow.)
- Header: display L `Your pack.` Mono caps subhead: `READY FOR THE TRIP`.
- Line items: product image (small, on roast color), Fraunces title, mono variant info, quantity stepper (mono numbers), price.
- Hairlines between items, no boxes.
- Right column (desktop) / below items (mobile): subtotal, shipping note (`SHIPS IN 2 DAYS · FLAT $5 · FREE OVER $40`), Resupply upsell card (7.7 condensed), checkout button (primary, full-width).
- Empty cart: display M `Nothing in the pack yet.` + secondary CTA "Browse the blends." No sad-cart animation. No emoji.

### 8.6 Blog / "Journal" (`templates/blog.json` + `templates/article.json`)
Renamed from "Blog" to **The Journal** in nav and on the page. The journal is field notes — brewing tips, location stories, supplier visits, gear we like, music we drink coffee to.

**Index (`blog.json`):**
- Header: display L `The Journal.` Mono subhead: `FIELD NOTES, BREW LOGS, OCCASIONAL OPINIONS.`
- Featured post: full-width card, large image left, headline + dek right.
- 2-up grid of subsequent posts, then 3-up for older posts.
- Each card: placeholder image (with topo line accent), display M title, Fraunces 16px dek, mono date.

**Article (`article.json`):**
- Hero: full-bleed image OR a roast color block if image-less, with display L title overlaid bottom-left.
- Body: max-width 680px, Fraunces 18px, generous leading, drop cap on first paragraph (display, 96px, `--ember`).
- Inline pull-quote component (Fraunces italic, 32px, with topo-line above and below).
- Footer of article: mono row with date, author, est. read time. Then a "More from the journal" 3-up.

### 8.7 404 (`templates/404.liquid`)
- Full-page `--pine` background, paper text.
- Display XL: `YOU'VE GONE OFFLINE.`
- Below, Fraunces 18px: *"Maybe that's the point. But if you meant to go somewhere specific…"*
- Then a two-line nav of mono links: `HOME / SHOP / JOURNAL / CONTACT`.
- A coordinate stamp top-right with random `N __° __' / W __° __'` generated per render.

### 8.8 Search results, Account, Login
Standard OS 2.0 templates. Apply the design system; don't invent new patterns. Use mono for form labels, hairlines for inputs (no full borders), display M for page titles.

---

## 9. Sections & blocks architecture

Build these `.liquid` section files in `/sections`. Every section has a `{% schema %}` block exposing settings so the merchant can edit without code.

### 9.1 Required sections
- `header.liquid` — top nav. Mono caps. Wordmark left, nav center, cart + account right. Sticky on scroll, with a 1px hairline that appears only after 80px of scroll. Mobile: hamburger that opens a full-screen `--paper` overlay with display M nav links.
- `footer.liquid` — see 7.8.
- `hero.liquid` — section 7.3. Settings: heading, subheading, primary CTA (text + link), secondary CTA, background type (roast color / image), roast color picker, coordinate stamp text.
- `featured-blends.liquid` — 3-up product card row with a section heading.
- `brew-strip.liquid` — section 7.6, with 4 step blocks (each has: number, title, body).
- `pull-quote.liquid` — section 7.4. Settings: quote, attribution, show topo line (bool).
- `editorial-grid.liquid` — N image+caption cards in a configurable column count.
- `resupply.liquid` — section 7.7. Settings: heading, three plan blocks (each has: name, frequency, sachets, price, microcopy).
- `journal-preview.liquid` — pulls from a chosen blog, shows N latest posts.
- `manifesto.liquid` — single big-type manifesto block.
- `origin-story.liquid` — image + text + coordinate stamp.
- `compost-callout.liquid` — full-bleed colored band for short brand-claim moments.
- `product-info.liquid` — main PDP right-column section.
- `tasting-card.liquid` — section 7.5, with 3 column blocks (aroma/palate/finish).
- `featured-product.liquid` — single-product highlight, used on home and inside articles.

### 9.2 Block patterns
Each "block" type should be reusable inside multiple sections via `{% raw %}{% for block in section.blocks %}{% endraw %}`. Blocks include: `text`, `image`, `quote`, `cta`, `tasting_tag`, `step`, `plan`, `accordion_item`. Define them once with sensible defaults; reuse aggressively.

### 9.3 App blocks
Leave **app block targets** open in: cart upsell area, PDP under-CTA area, footer above the wordmark, and homepage between hero and featured-blends. So the merchant can add reviews, email capture, or upsell apps without code.

---

## 10. Theme settings (`config/settings_schema.json`)

Expose at minimum:
- **Colors:** ink, paper, paper-2, amber, ember, pine (so the merchant can tune if needed — but defaults are locked to the brand).
- **Typography:** font_picker for display, body, mono. Defaults to the chosen faces.
- **Layout:** max page width, section spacing scale toggle (compact / standard / spacious).
- **Brand:** logo upload (light + dark), favicon, default coordinate stamp text, social handles.
- **Header:** sticky toggle, announcement bar text + link (default: `STEEPED. NOT INSTANT. — FREE SHIPPING OVER $40`).
- **Footer:** wordmark size (S/M/L/XL), three column heading texts, fine-print text.
- **Product card:** show signal bars (bool), show tasting tags (bool), max tags (1–4).
- **Performance:** lazy-load images (default on), preload hero (default on).

---

## 11. Liquid + technical requirements

### 11.1 Stack
- **Liquid** templating, OS 2.0 (`.json` templates everywhere it's reasonable).
- **No** jQuery. Vanilla JS only, ES2020+.
- **No** CSS framework (no Tailwind, no Bootstrap). Hand-written CSS using **CSS variables** for the design tokens, **CSS Grid** for layout, **logical properties** (`margin-block`, `padding-inline`) for RTL-readiness.
- **One** stylesheet entry: `assets/theme.css`. Split source into partials but build to a single file. Goal: < 80KB minified, < 25KB gzipped.
- **One** JS entry: `assets/theme.js`. Goal: < 30KB minified, < 12KB gzipped.

### 11.2 Image pipeline
Every image must use Liquid's `image_url` filter with responsive `widths`:
```liquid
{% raw %}
{{ image | image_url: width: 1600 | image_tag:
   loading: 'lazy',
   widths: '400, 600, 800, 1200, 1600, 2400',
   sizes: '(min-width: 990px) 50vw, 100vw',
   alt: image.alt | escape,
   class: 'media' }}
{% endraw %}
```
Hero image: `loading="eager"` and `fetchpriority="high"`, plus a `<link rel="preload" as="image">` in `theme.liquid` head.

### 11.3 Fonts
- Self-host the chosen fonts under `/assets/fonts/`. Use `@font-face` with `font-display: swap`.
- Subset to Latin + Latin-Extended.
- Preload only the two fonts that appear above the fold (display 800 + Fraunces 400).

### 11.4 Structured data
- Verify Shopify's auto-injected Product, Organization, BreadcrumbList JSON-LD is firing.
- Add `Article` JSON-LD on `article.liquid`.

### 11.5 Performance budgets
- LCP < 2.0s on Slow 4G mobile.
- CLS < 0.05.
- INP < 200ms.
- Total page weight on home: < 800KB (excluding hero video, if added later).

### 11.6 Accessibility
- WCAG **AA** minimum, AAA where reasonable.
- Visible focus rings: 2px `--ink` outline, 2px offset. Never `outline: none` without replacement.
- All interactive elements ≥ 44×44px touch target.
- Skip-to-content link in header.
- ARIA labels on icon-only buttons (cart, search, account).
- `prefers-reduced-motion` respected: disable any transform/translate animations, keep opacity fades only.

### 11.7 Internationalization
- Wrap all UI strings in `{% raw %}{{ 'general.cart.title' | t }}{% endraw %}` style locale calls.
- Ship `locales/en.default.json` complete; stub `fr.json` for future.

---

## 12. Microcopy library

Use these verbatim where applicable; rewrite to match if context requires. Voice = section 1.2.

- **Add to cart:** `Add to pack`
- **Cart:** `Your pack`
- **Checkout:** `Check out`
- **Subscribe:** `Resupply`
- **Empty cart:** `Nothing in the pack yet.`
- **Empty search:** `Nothing matches that. Try one of these blends.`
- **Out of stock:** `Out of range — back next week.`
- **Newsletter signup:** `Notes from offline. Once a month, no urgency.`
- **404 sub:** `Maybe that's the point.`
- **Shipping line:** `Ships in 2 days · Flat $5 · Free over $40`
- **Compost line:** `100% plant-based filter · OK for your backyard compost`
- **Subscribe microcopy:** `Skip or cancel anytime — really.`
- **Footer fine print:** `Roasted in small batches. Steeped wherever you are.`
- **Announcement bar:** `STEEPED. NOT INSTANT. — FREE SHIPPING OVER $40`

---

## 13. The "Offline" details (delight)

These are small, optional moments that make the theme feel made, not generated. Pick at least 4 to ship.

1. **Cursor coordinate.** A tiny mono-type readout in the bottom-right of the page that updates with the cursor's position as `N __° __' / W __° __'`. Disabled on mobile (no cursor). Disabled on `prefers-reduced-motion`.
2. **No-WiFi 404.** The 404 page renders with a one-time "loading…" delay of ~600ms, then snaps into the offline screen, like a network failure. Easter egg, not annoying.
3. **Klaxon-free hover states.** Product card hover shifts the bag image up 8px and that's the entire animation. No glow, no zoom, no shimmer.
4. **Brewing timer on PDP.** Below the brew strip, a small interactive 4-minute timer button (`START BREW`) that counts down in mono digits. Plays no sound. When it hits 00:00, type changes to `READY.`
5. **Roast spectrum bar in the footer.** A horizontal gradient strip from `--amber` → `--ember` → `--pine`, full-width, 8px tall, sitting just above the footer's giant wordmark. Each color anchors a tiny mono label below: `LIGHT` `MEDIUM` `DARK`.
6. **"Going offline…" loading state.** When navigating between pages, a 200ms fade-out of content with a tiny mono `GOING OFFLINE…` bottom-left, then the new page fades in.
7. **Postcard checkout confirmation.** The order confirmation page is styled like a postcard back: stamp top-right, address-style order details left, handwritten-feeling thank you (still Fraunces italic — no script fonts).
8. **Reduced-motion mode is just as good.** All delight features must have a static fallback. The coordinate readout becomes a fixed value. The timer becomes a static `4:00 BREW TIME` label. The fade transitions become instant.

---

## 14. Deliverable file tree

```
offline-theme/
├── assets/
│   ├── theme.css              (single compiled stylesheet)
│   ├── theme.js               (single compiled script)
│   ├── fonts/                 (self-hosted woff2)
│   ├── icons/                 (signal-bars.svg, topo-line.svg, postage.svg)
│   ├── logo-light.png         (Offline_Coffee.png)
│   └── logo-dark.png          (Offline_Coffee__1_.png)
├── config/
│   ├── settings_schema.json
│   └── settings_data.json
├── layout/
│   ├── theme.liquid
│   └── password.liquid
├── locales/
│   ├── en.default.json
│   └── fr.json                (stub)
├── sections/
│   ├── header.liquid
│   ├── footer.liquid
│   ├── hero.liquid
│   ├── featured-blends.liquid
│   ├── brew-strip.liquid
│   ├── pull-quote.liquid
│   ├── editorial-grid.liquid
│   ├── resupply.liquid
│   ├── journal-preview.liquid
│   ├── manifesto.liquid
│   ├── origin-story.liquid
│   ├── compost-callout.liquid
│   ├── product-info.liquid
│   ├── tasting-card.liquid
│   ├── featured-product.liquid
│   ├── main-collection.liquid
│   ├── main-cart.liquid
│   ├── main-article.liquid
│   ├── main-blog.liquid
│   └── main-search.liquid
├── snippets/
│   ├── product-card.liquid
│   ├── button.liquid
│   ├── icon.liquid
│   ├── coordinate-stamp.liquid
│   ├── signal-bars.liquid
│   ├── topo-line.liquid
│   ├── price.liquid
│   ├── accordion-item.liquid
│   ├── responsive-image.liquid
│   └── meta-tags.liquid
└── templates/
    ├── index.json
    ├── collection.json
    ├── product.json
    ├── cart.json
    ├── blog.json
    ├── article.json
    ├── page.about.json
    ├── page.json
    ├── search.json
    ├── 404.liquid
    └── customers/
        ├── account.json
        ├── login.json
        ├── register.json
        ├── order.json
        ├── addresses.json
        └── reset_password.json
```

---

## 15. Acceptance criteria

The build is done when **all** of these are true:

- [ ] Theme uploads cleanly to a Shopify dev store via Shopify CLI (`shopify theme push`) with no errors.
- [ ] All page templates render without fallbacks or broken sections.
- [ ] The merchant can edit hero text, swap images, reorder sections, and change the announcement bar entirely from the theme editor — no code edit required.
- [ ] Color tokens flow from `settings_data.json` through to CSS variables — changing `--pine` in settings changes every dark-roast surface site-wide.
- [ ] Lighthouse mobile (Slow 4G profile): Performance ≥ 90, Accessibility = 100, SEO ≥ 95, Best Practices = 100.
- [ ] LCP < 2.0s, CLS < 0.05, INP < 200ms on the home page.
- [ ] Every image has meaningful `alt` text or empty alt for decorative cases.
- [ ] Keyboard navigation works through home → collection → PDP → cart → checkout. Focus rings visible at every step.
- [ ] Reduced-motion mode disables all transforms; opacity fades remain.
- [ ] No `<img>` uses an external `src` — all routed through `image_url`.
- [ ] No console errors, no console warnings, no 404s on assets.
- [ ] Theme weighs < 1MB total (excluding fonts).
- [ ] At least 4 of the 8 "delight" features from section 13 are shipped.
- [ ] The 404, empty cart, and search-no-results pages all feel like the rest of the brand — not Shopify defaults.

---

## 16. What "good" feels like

When the merchant opens the dev store for the first time, they should feel two things, in order:

1. **"This is mine."** The brand is already there. The voice is right. The colors land. Nothing on the screen says "Dawn theme." Nothing says "AI-generated." It feels like a designer who understood the product spent six weeks in the brand.
2. **"I can run this."** Every section is editable from the theme editor. The schema is named in plain English. Nothing requires a developer for normal day-to-day edits.

If the homepage hero, the product card, and the footer wordmark all feel like the same world — and that world is recognizably "Offline" within five seconds of looking — the build has succeeded.

---

## 17. What to ask if anything's unclear

Before scaffolding the file tree, raise a question if any of these are blockers:
- Is the merchant on Shopify Plus, Advanced, or Basic? (Affects checkout customization scope.)
- Are there real product names yet, or should the build use placeholder names like "Aspen Morning," "Desert Ember," "Pine Hollow"?
- Is the merchant using Shopify's native subscription product (Subscriptions app), or a third-party (Recharge, Bold)? Affects the Resupply section integration.
- Are there confirmed origin countries / roast specs for the three blends, or should those use plausible placeholder copy?

If none of these have answers, **ship the build with sensible placeholder content** and clearly mark every placeholder string with `<!-- TODO: replace with real copy -->` in the Liquid.

---

**Now build it.** Treat the brief as a contract, the brand voice as the personality of every word, and the design system as a tight set of constraints inside which to be unexpected. The brand is "Offline." The site should feel like a place you'd want to be — not another tab.
